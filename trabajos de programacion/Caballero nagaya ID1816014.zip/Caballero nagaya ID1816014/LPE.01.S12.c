#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
int validar_num(char numero[50]);
int main(){
	int sw;
	char numero[50], nombre[50];
	fflush(stdin);
	printf("Ingrese un numero:");
	gets(numero);
	
	sw= validar_num(numero);
	
	if(sw==0) {printf("Numero Valido\n");}
	else {printf("Numero Invalido\n");}
	
	system("pause");
}
int validar_num(char numero[50]){
	int i=0,sw=0,j;
	j=strlen(numero);
	while(i<j && sw==0){
		if(isdigit(numero[i])!=0){
		i++;}
		else{ sw=1;}
	}
	return sw;
}
