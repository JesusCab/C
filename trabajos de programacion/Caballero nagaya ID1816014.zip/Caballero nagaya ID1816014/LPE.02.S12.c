#include <stdio.h>
#include <stdlib.h>
#include <math.h>
void menu();
int leer();
int imp();
int suma(int x,int y);
int resta(int x,int y);
int multi(int x,int y);
int di(int x,int y);

int main(){
	int opc,x,y,z;
	menu();
	opc=leer(opc);
	fflush(stdin);
	system("cls");
	switch(opc) 
	{
	    case 1:x=leer(x); y=leer(y); z=suma(x,y); printf("\n\tresultado: %d",z);
		break;
		case 2:x=leer(x); y=leer(y);  z=resta(x,y); printf("\n\tresultado: %d",z);
		break;
		case 3:x=leer(x); y=leer(y);  z=multi(x,y); printf("\n\tresultado: %d",z);
		break;
		case 4:x=leer(x); y=leer(y); z=di(x,y); printf("\n\tresultado: %d",z);
		break;
		case 5:printf("\n\n\t--------------------Hasta Pronto!!!--------------------"); 
		break;
	}
	printf("\n\n");
	system("pause");
}

void menu(){
printf("\nMENU:\n\t1.-Suma\n\t2.-Resta\n\t3.-Multiplicacion\n\t4.-Division\n\t5.-Salir.");
}
int leer(){
	int n;
	printf("\n\tIntroduce un numero:");
	scanf("%d",&n);
	fflush(stdin);
	return n;
}

int suma(int x,int y){
	int z;
	z=x+y;
	return z;
}
int resta(int x,int y){
	int z;
	z=x-y;
	return z;
}
int multi(int x,int y){
	int z;
	z=x*y;
	return z;
}
int di(int x,int y){
	int z;
	z=x/y;
	return z;
}
